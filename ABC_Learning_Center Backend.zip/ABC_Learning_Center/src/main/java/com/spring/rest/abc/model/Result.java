package com.spring.rest.abc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

@Entity
@EnableAutoConfiguration
public class Result {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String stdnt_no;
	private String stdnt_name;
	private String academic_year;
	private String stdnt_percentage;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStdnt_no() {
		return stdnt_no;
	}
	public void setStdnt_no(String stdnt_no) {
		this.stdnt_no = stdnt_no;
	}
	public String getStdnt_name() {
		return stdnt_name;
	}
	public void setStdnt_name(String stdnt_name) {
		this.stdnt_name = stdnt_name;
	}
	public String getAcademic_year() {
		return academic_year;
	}
	public void setAcademic_year(String academic_year) {
		this.academic_year = academic_year;
	}
	public String getStdnt_percentage() {
		return stdnt_percentage;
	}
	public void setStdnt_percentage(String stdnt_percentage) {
		this.stdnt_percentage = stdnt_percentage;
	}
	
	public Result(int id, String stdnt_no, String stdnt_name, String academic_year, String stdnt_percentage) {
		super();
		this.id = id;
		this.stdnt_no = stdnt_no;
		this.stdnt_name = stdnt_name;
		this.academic_year = academic_year;
		this.stdnt_percentage = stdnt_percentage;
	}
	@Override
	public String toString() {
		return "Result [id=" + id + ", stdnt_no=" + stdnt_no + ", stdnt_name=" + stdnt_name + ", academic_year="
				+ academic_year + ", stdnt_percentage=" + stdnt_percentage + "]";
	}
	
	public Result() {
		
	}
	
	
	
}
