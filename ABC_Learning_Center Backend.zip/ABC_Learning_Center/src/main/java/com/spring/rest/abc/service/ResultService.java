package com.spring.rest.abc.service;

import java.util.List;
import java.util.Optional;

import com.spring.rest.abc.model.Result;

public interface ResultService {
	
	public List<Result> getAllResult();
	
}
