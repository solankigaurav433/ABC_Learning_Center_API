package com.spring.rest.abc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.rest.abc.model.Result;

public interface ResultRepo extends JpaRepository<Result, Integer> {

}
