package com.spring.rest.abc.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.rest.abc.model.Users;
import com.spring.rest.abc.repo.UserRepo;

@Service
@Transactional
public class UserServiceImpl implements UserService
{

	@Autowired
	private UserRepo repo;
	
	@Override
	public Users addUser(Users user) {
		
		return repo.save(user);
	}

	@Override
	public Users getUserById(int id) {
		Users user=null;
		Optional<Users> oldUser = repo.findById(id);
		if(oldUser.isPresent()) {
			user=oldUser.get();
		}
		return user;
	}

	@Override
	public Optional<Users> findUserById(int id) {
		
		return repo.findById(id);
	}

	@Override
	public List<Users> getAllUser() {
		
		return repo.findAll();
	}

	@Override
	public Users findUserByName(String name) {
		// TODO Auto-generated method stub
		return repo.findByUsername(name);
	}

	

}
