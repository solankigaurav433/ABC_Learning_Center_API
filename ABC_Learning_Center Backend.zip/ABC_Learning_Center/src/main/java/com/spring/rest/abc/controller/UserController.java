package com.spring.rest.abc.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.rest.abc.model.Users;
import com.spring.rest.abc.service.UserService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/userData")
public class UserController {

	@Autowired
	private UserService service;
	
	@Autowired
	private BCryptPasswordEncoder bcrypt;
	
	@PostMapping("/register")
	public Users addUsers(@RequestBody Users user) {
		user.setPassword(bcrypt.encode(user.getPassword()));
		return service.addUser(user);
	}

	@GetMapping("/user")
	public List<Users> getAllUser(){
		return service.getAllUser()
;	}
	
	@GetMapping("/user/{id}")
	public Optional<Users> findUserById(@PathVariable int id){
		return service.findUserById(id);
	}
	
	@GetMapping("/user/Detail/{name}")
	public Users findUserByName(@PathVariable String name){
		System.out.println("In User Detail "+ name);
		return service.findUserByName(name);
	}
	
	
	@PutMapping("/user/{id}")
	public Users updateUsers(@RequestBody Users user, @PathVariable int id) {
		Optional<Users> oldUser = service.findUserById(id);
		if (oldUser.isPresent()) {
			Users obj = oldUser.get();
			obj.setName(user.getName());
			obj.setEmail(user.getEmail());
			obj.setNumber(user.getNumber());
			obj.setUsername(user.getUsername());
			return service.addUser(obj);
		}
		else {
			return null;
		}	
	}
}
