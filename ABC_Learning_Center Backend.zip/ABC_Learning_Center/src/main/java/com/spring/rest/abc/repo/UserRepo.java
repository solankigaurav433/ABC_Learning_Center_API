package com.spring.rest.abc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.rest.abc.model.Users;

public interface UserRepo extends JpaRepository<Users, Integer> {
	
	public Users findByUsername(String username);
	
}
