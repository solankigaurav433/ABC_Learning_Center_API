package com.spring.rest.abc.service;

import java.util.List;
import java.util.Optional;

import com.spring.rest.abc.model.Users;

public interface UserService {

	public Users addUser(Users user);
	public Users getUserById(int id);
	public Optional<Users> findUserById(int id);
	public List<Users> getAllUser();
	public Users findUserByName(String name);
}
