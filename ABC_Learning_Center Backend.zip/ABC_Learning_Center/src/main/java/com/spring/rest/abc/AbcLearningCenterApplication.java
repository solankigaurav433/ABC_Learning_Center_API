package com.spring.rest.abc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan("com.spring.rest.abc")
@ComponentScan("com.spring.rest.abc")
@EnableJpaRepositories("com.spring.rest.abc")
public class AbcLearningCenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcLearningCenterApplication.class, args);
	}

}
